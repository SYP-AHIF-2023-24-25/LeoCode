module.exports = {
    require: 'ts-node/register',
    spec: '**/*.spec.ts',
}