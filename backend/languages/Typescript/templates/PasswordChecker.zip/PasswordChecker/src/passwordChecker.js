"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CheckPassword = void 0;
function CheckPassword(password) { return true; }
exports.CheckPassword = CheckPassword;
