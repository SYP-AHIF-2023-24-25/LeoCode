export function BubbleTest(bubble: string): boolean {
    return true;
}