"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BubbleTest = void 0;
function BubbleTest(bubble) {
    return true;
}
exports.BubbleTest = BubbleTest;
