export function BubbleTest(bubble: string): boolean {
    //Todo: Implement bubble test
    return true;
}